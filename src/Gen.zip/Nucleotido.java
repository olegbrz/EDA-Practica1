
public class Nucleotido {
	private char nucleotido;
	
	Nucleotido(char c){
		this.nucleotido = c;
	}
	
	public char getNucleotido() {
		return nucleotido;
	}
}
